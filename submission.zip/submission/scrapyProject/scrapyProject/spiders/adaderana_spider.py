import scrapy
from ..items import NewsItem


class ArticleSpider(scrapy.Spider):
    name = 'Adaderana'
    start_urls = [
        'http://sinhala.adaderana.lk/sinhala-hot-news.php'
    ]

    def parse(self, response):
        for type_href in response.css('.footer-nav a::attr(href)')[:-3]:
            url = response.urljoin(type_href.extract())
            yield scrapy.Request(url, callback=self.crawl_page)

    def crawl_page(self, response):
        category = response.css('.category-heading::text').extract_first()
        for article_href in response.css('h2 a::attr(href)'):
            url = response.urljoin(article_href.extract())
            yield scrapy.Request(url, callback=self.crawl_article, meta={'category': category})

    def crawl_article(self, response):
        items = NewsItem()

        title = response.css('.news-heading::text').extract_first()
        content = response.css('.news-content p::text').extract_first()
        date = response.css('.news-datestamp::text').extract_first()

        types = ["දේශීය", "විදේශීය", "ව්‍යාපාරික", "ක්‍රීඩා", "තාක්ෂණික", "වෙනත්"]

        items['publisher'] = "අද දෙරණ"
        items['title'] = title
        items['content'] = content
        items['date'] = date
        if response.meta.get('category') == "උණුසුම් පුවත්":
            items['category'] = types[0]
        elif response.meta.get('category') == "ව්\u200dයාපාරික පුවත්":
            items['category'] = types[2]
        elif response.meta.get('category') == "වෙනත් පුවත්":
            items['category'] = types[5]
        elif response.meta.get('category') == "ක්\u200dරීඩා පිට්ය":
            items['category'] = types[3]
        elif response.meta.get('category') == "සයුරෙන් එතෙර":
            items['category'] = types[1]
        else:
            items['category'] = types[5]

        yield items

import scrapy
from ..items import NewsItem


class ArticleSpider(scrapy.Spider):
    name = 'BBC_Sinhala'
    start_urls = [
        'https://www.bbc.com/sinhala'
    ]

    def parse(self, response):
        for type_href in response.css('.navigation-wide-list__link::attr(href)')[1:-1]:
            url = response.urljoin('https://www.bbc.com' + type_href.extract())
            yield scrapy.Request(url, callback=self.crawl_page)

    def crawl_page(self, response):
        category = response.css('div h1::text').extract_first()
        for article_href in response.css('.title-link::attr(href)'):
            url = response.urljoin('https://www.bbc.com' + article_href.extract())
            yield scrapy.Request(url, callback=self.crawl_article, meta={'category': category})

    def crawl_article(self, response):
        items = NewsItem()

        title = response.css('.story-body__h1::text').extract_first()
        content = response.css('.story-body__link , .story-body__inner p').css('::text').extract_first()
        date = response.css('.mini-info-list__item .date--v2::text').extract_first()

        types = ["දේශීය", "විදේශීය", "ව්‍යාපාරික", "ක්‍රීඩා", "තාක්ෂණික", "වෙනත්"]

        items['publisher'] = "බීබීසී සිංහල"
        items['title'] = title
        items['content'] = content
        items['date'] = date
        if response.meta.get('category') == "ශ්\u200dරී ලංකා":
            items['category'] = types[0]
        elif response.meta.get('category') == "විද්\u200dයාව":
            items['category'] = types[4]
        elif response.meta.get('category') == "ක්\u200dරීඩා":
            items['category'] = types[3]
        elif response.meta.get('category') == "ලෝකය":
            items['category'] = types[1]
        else:
            items['category'] = types[5]
        print(items)

        yield items

import scrapy
from ..items import NewsItem


class ArticleSpider(scrapy.Spider):
    name = 'Silumina'
    start_urls = [
        'http://www.silumina.lk/'
    ]

    def parse(self, response):
        for type_href in response.css('li a::attr(href)')[1:12]:
            url = response.urljoin('http://www.silumina.lk' + type_href.extract())
            yield scrapy.Request(url, callback=self.crawl_page)

    def crawl_page(self, response):
        category = response.css('div h1::text').extract_first()
        for article_href in response.css('.views-field-title a::attr(href)'):
            url = response.urljoin('http://www.silumina.lk' + article_href.extract())
            yield scrapy.Request(url, callback=self.crawl_article, meta={'category': category})

    def crawl_article(self, response):
        items = NewsItem()

        title = response.css('h1::text').extract_first()
        content = response.css('#block-system-main p').css('::text').extract_first()
        date = response.css('.date-display-single::text').extract_first()

        types = ["දේශීය", "විදේශීය", "ව්‍යාපාරික", "ක්‍රීඩා", "තාක්ෂණික", "වෙනත්"]

        items['publisher'] = "සිළුමිණ"
        items['title'] = title
        items['content'] = content
        items['date'] = date
        if response.meta.get('category') == "පුවත්" or response.meta.get('category') == "දේශපාලනය":
            items['category'] = types[0]
        elif response.meta.get('category') == "ක්\u200dරීඩා":
            items['category'] = types[3]
        elif response.meta.get('category') == "විදෙස්":
            items['category'] = types[1]
        else:
            items['category'] = types[5]
        print(items)

        yield items
